// .netlify/functions/ai-chat.js
var https = require("https");
var SUPABASE_URL = process.env.SUPABASE_URL || "https://dljvplrbjogncwrpmfsj.supabase.co";
var SERVICE_ROLE = process.env.SUPABASE_SERVICE_ROLE || "";
var GEMINI_KEYS = (process.env.GEMINI_KEYS || process.env.GEMINI_API_KEY || "").split(",").map((k) => k.trim()).filter(Boolean);
var GROQ_KEY = process.env.GROQ_API_KEY || "";
var OPENAI_KEY = process.env.OPENAI_API_KEY || "";
function httpsRequest(url, options, body) {
  return new Promise((resolve, reject) => {
    const req = https.request(url, options, (res) => {
      let data = "";
      res.on("data", (chunk) => {
        data += chunk;
      });
      res.on("end", () => {
        resolve({ status: res.statusCode, headers: res.headers, body: data });
      });
    });
    req.on("error", reject);
    if (body) req.write(body);
    req.end();
  });
}
async function supabaseQuery(tablePath) {
  const url = `${SUPABASE_URL}/rest/v1/${tablePath}`;
  const opts = {
    method: "GET",
    headers: {
      apikey: SERVICE_ROLE,
      Authorization: `Bearer ${SERVICE_ROLE}`,
      "Content-Type": "application/json"
    }
  };
  const result = await httpsRequest(url, opts);
  if (result.status >= 400) return [];
  try {
    return JSON.parse(result.body);
  } catch (e) {
    return [];
  }
}
async function fetchLiveContext(user) {
  try {
    const [sites, users, stock, requests, grns, transfers] = await Promise.all([
      supabaseQuery("sites?select=id,name,type,is_active&order=id.asc"),
      supabaseQuery("users?select=id,name,email,role,position,site_ids,is_active&order=name.asc"),
      supabaseQuery("stock?select=id,site_id,material_name,quantity,unit,category,unit_price,production_date,expiry_date,last_updated&order=last_updated.desc.nullslast&limit=1000"),
      supabaseQuery("material_requests?select=id,site_id,status,urgency,created_at,items&limit=50"),
      supabaseQuery("grns?select=id,site_id,grn_number,invoice_number,status,total_value,supplier,created_at,items&limit=30"),
      supabaseQuery("transfers?select=id,from_site_id,to_site_id,status,created_at,material_name,quantity&limit=30")
    ]);
    const activeSites = (sites || []).filter((s) => s.is_active);
    const activeUsers = (users || []).filter((u) => u.is_active);
    const pendingReqs = (requests || []).filter((r) => r.status === "pending");
    const pendingGrns = (grns || []).filter((g) => g.status === "pending");
    const pendingTransfers = (transfers || []).filter((t) => t.status === "pending");
    return {
      sites: sites || [],
      activeSiteCount: activeSites.length,
      users: users || [],
      activeUserCount: activeUsers.length,
      stock: stock || [],
      totalStockItems: (stock || []).length,
      pendingReqs,
      pendingReqCount: pendingReqs.length,
      pendingGrns,
      pendingGrnCount: pendingGrns.length,
      pendingTransfers,
      pendingTransferCount: pendingTransfers.length
    };
  } catch (err) {
    console.warn("[ai-chat] Context fetch fallback:", err.message);
    return {};
  }
}
function generateDeepReasoning(prompt, user, ctx, history = []) {
  const rawQ = prompt.trim();
  const q = rawQ.toLowerCase().replace(/[^a-z0-9\s@\.]/g, " ").replace(/\s+/g, " ").trim();
  function score(keywords) {
    let s = 0;
    for (const kw of keywords) {
      if (q.includes(kw)) s += kw.length;
    }
    return s;
  }
  const userName = user.name ? user.name.split(" ")[0] : "there";
  const stock = ctx.stock || [];
  const sites = ctx.sites || [];
  const users = ctx.users || [];
  const siteName = (id) => {
    const s = sites.find((x) => x.id === id);
    return s ? s.name : `Site ${id}`;
  };
  const credScore = score(["password", "credential", "crediantial", "cred", "login", "access", "sign in", "username", "account info", "log in", "passw"]);
  const userScore = score(["user", "team", "personnel", "staff", "employee", "who are", "roster", "member", "how many user", "list user", "all user"]);
  const expiryScore = score(["expir", "shelf", "perish", "spoil", "old stock", "aging", "due date", "expire", "expiry", "best before", "use by"]);
  const lowStockScore = score(["low stock", "shortage", "running low", "reorder", "depleted", "out of stock", "critical stock", "less than", "minimum"]);
  const sitesScore = score(["site", "project", "location", "all project", "show site", "list site", "our project", "how many site", "active project"]);
  const transferScore = score(["transfer", "transit", "dispatch", "move stock", "inter.site"]);
  const requestScore = score(["request", "approval", "mrn", "requisition", "pending request", "material request", "order"]);
  const greetScore = score(["hello", "hi ", "hey", "status", "help me", "how are", "what can", "good morning", "good afternoon"]);
  const technicalScore = score(["concrete", "mix ratio", "curing", "slump", "grade", "rebar", "column", "slab", "beam", "foundation", "cement ratio", "water cement"]);
  const costScore = score(["cost", "price", "value", "worth", "budget", "ksh", "kes", "money", "spend", "spent", "expensive"]);
  const mentionedUser = users.find((u) => {
    if (!u.name && !u.email) return false;
    const nameWords = (u.name || "").toLowerCase().split(" ").filter((w) => w.length > 2);
    const email = (u.email || "").toLowerCase();
    return nameWords.some((w) => q.includes(w)) || email && q.includes(email.split("@")[0]);
  });
  if (mentionedUser && (credScore > 0 || q.includes("info") || q.includes("detail") || q.includes("for ") || q.includes("about"))) {
    const u = mentionedUser;
    const siteList = Array.isArray(u.site_ids) && u.site_ids.length > 0 ? u.site_ids.map((id) => siteName(id)).join(", ") : "All Sites";
    return `Here are the details for **${u.name}**:

\u2022 **Email / Username**: \`${u.email}\`
\u2022 **Role**: ${u.role.replace(/_/g, " ")}
\u2022 **Position**: ${u.position || "\u2014"}
\u2022 **Sites**: ${siteList}
\u2022 **Status**: ${u.is_active ? "\u2705 Active" : "\u23F8\uFE0F Disabled"}

\u{1F510} **Default Login Password**: \`canaan123\`
*(Administrators can reset the password via **Manage Users \u2192 Edit User**)*`;
  }
  const materialKeywords = q.split(" ").filter((w) => w.length > 2 && !["what", "where", "how", "show", "tell", "about", "many", "much", "the", "and", "for", "are", "are", "have", "item", "give", "need", "site", "project", "stock", "all", "our", "does", "that", "this", "with", "from", "which", "they"].includes(w));
  const matchedMaterials = materialKeywords.length > 0 ? stock.filter((item) => {
    const name = (item.material_name || "").toLowerCase();
    const cat = (item.category || "").toLowerCase();
    return materialKeywords.some((k) => name.includes(k) || cat.includes(k));
  }) : [];
  const matchedSite = sites.find((s) => {
    const sn = s.name.toLowerCase();
    const parts = sn.split(" ").filter((w) => w.length > 3);
    return parts.some((p) => q.includes(p));
  });
  const maxScore = Math.max(credScore, userScore, expiryScore, lowStockScore, sitesScore, transferScore, requestScore, greetScore, technicalScore, costScore);
  if (credScore >= 4 && credScore === maxScore) {
    return `### \u{1F510} CDL System Access & Credentials

\u2022 **Default System Password** (all accounts): \`canaan123\`
\u2022 **Admin Email**: \`admin@canaan.co.ke\`
\u2022 **Data Holder**: \`dh@canaan.co.ke\` / \`canaan123\`
\u2022 **CEO**: \`ceo@canaan.co.ke\` / \`canaan123\`
\u2022 **Owner**: \`owner@canaan.co.ke\` / \`canaan123\`

\u{1F4A1} All user accounts provisioned through **Manage Users** are assigned the default password \`canaan123\` automatically.

Admins can reset or disable any account from the **Manage Users** dashboard.`;
  }
  if (userScore > 3 && (userScore >= credScore || credScore < 4)) {
    const roleCounts = {};
    users.forEach((u) => {
      roleCounts[u.role] = (roleCounts[u.role] || 0) + 1;
    });
    const breakdown = Object.entries(roleCounts).sort((a, b) => b[1] - a[1]).map(([r, c]) => `\u2022 **${r.replace(/_/g, " ").toUpperCase()}**: ${c}`).join("\n");
    const sample = users.slice(0, 6).map((u) => `\u2022 **${u.name}** (${u.email}) \u2014 ${u.role.replace(/_/g, " ")}`).join("\n");
    return `We have **${ctx.activeUserCount || users.length} active team members** across all CDL sites:

### \u{1F465} By Role:
${breakdown}

### Sample Accounts:
${sample}

*(Full list in **Manage Users**)*`;
  }
  if (expiryScore > 3) {
    const today = /* @__PURE__ */ new Date();
    const expiring = stock.filter((i) => i.expiry_date).map((i) => ({ ...i, daysLeft: Math.ceil((new Date(i.expiry_date) - today) / 864e5) })).filter((i) => i.daysLeft <= 60).sort((a, b) => a.daysLeft - b.daysLeft);
    if (expiring.length === 0) return `All good! No materials are within the critical 60-day expiration window across any of our ${ctx.activeSiteCount} sites.

*(PPR pipes, steel rebar, timber, and aggregates are non-perishable \u2014 they don't expire.)*`;
    const list = expiring.slice(0, 8).map((i) => {
      const flag = i.daysLeft < 0 ? `\u274C Expired ${Math.abs(i.daysLeft)}d ago` : i.daysLeft <= 7 ? `\u{1F534} CRITICAL \u2014 expires in ${i.daysLeft} days (${i.expiry_date})` : i.daysLeft <= 30 ? `\u{1F7E0} Expiring in ${i.daysLeft} days (${i.expiry_date})` : `\u{1F7E1} Expiring in ${i.daysLeft} days (${i.expiry_date})`;
      return `\u2022 **${i.material_name}** \u2014 ${i.quantity} ${i.unit || "units"} @ **${siteName(i.site_id)}**
  ${flag}`;
    }).join("\n\n");
    return `I found **${expiring.length} item(s)** approaching or past their expiry date:

${list}

\u{1F4A1} Recommend using or transferring urgent batches to high-consumption sites immediately.`;
  }
  if (lowStockScore > 3) {
    const low = stock.filter((i) => parseFloat(i.quantity) > 0 && parseFloat(i.quantity) <= 15);
    if (!low.length) return `Stock levels look healthy across all sites \u2014 no critical shortages detected right now.`;
    const list = low.slice(0, 8).map((i) => `\u2022 **${i.material_name}**: only **${i.quantity} ${i.unit || "units"}** left @ ${siteName(i.site_id)}`).join("\n");
    return `\u26A0\uFE0F **${low.length} items** are running low across our sites:

${list}

Would you like to raise a material requisition or arrange a transfer from the Central Store?`;
  }
  if (matchedSite) {
    const siteStock = stock.filter((i) => i.site_id === matchedSite.id);
    const siteReqs = (ctx.pendingReqs || []).filter((r) => r.site_id === matchedSite.id);
    const stockList = siteStock.length ? siteStock.slice(0, 8).map((i) => `\u2022 **${i.material_name}**: ${i.quantity} ${i.unit || "units"}`).join("\n") + (siteStock.length > 8 ? `
\u2022 *...and ${siteStock.length - 8} more*` : "") : "No active materials recorded yet.";
    return `### \u{1F4CD} ${matchedSite.name}

\u2022 **Type**: ${matchedSite.type}
\u2022 **Status**: ${matchedSite.is_active ? "\u2705 Active" : "\u23F8\uFE0F Inactive"}
\u2022 **Open Requests**: ${siteReqs.length}
\u2022 **Inventory Lines**: ${siteStock.length}

**Stock on Site:**
${stockList}`;
  }
  if (costScore > 3) {
    const totalValue = stock.reduce((s, i) => s + (parseFloat(i.quantity) || 0) * (parseFloat(i.unit_price) || 0), 0);
    const bySite = {};
    stock.forEach((i) => {
      const sn = siteName(i.site_id);
      bySite[sn] = (bySite[sn] || 0) + (parseFloat(i.quantity) || 0) * (parseFloat(i.unit_price) || 0);
    });
    const breakdown = Object.entries(bySite).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([s, v]) => `\u2022 **${s}**: KES ${v.toLocaleString()}`).join("\n");
    return `Our total live inventory value across all sites is **KES ${totalValue.toLocaleString()}**

### Top Sites by Value:
${breakdown}`;
  }
  if (sitesScore > 3 && matchedMaterials.length === 0) {
    const list = sites.map((s) => `\u2022 **${s.name}** \u2014 ${s.type} (${s.is_active ? "Active" : "Inactive"})`).join("\n");
    return `CDL is managing **${ctx.activeSiteCount || sites.length} active projects** across Nairobi:

${list}

All sites share the central inventory and requisition network.`;
  }
  if (transferScore > 3) {
    const t = ctx.pendingTransfers || [];
    return `There are **${t.length} inter-site transfer(s)** currently in transit or awaiting confirmation.

All transfers go through central dispatch at GRS/Mlolongo. You can track and approve them in the **Transfers** module.`;
  }
  if (requestScore > 3) {
    const r = ctx.pendingReqs || [];
    return `We have **${r.length} pending material request(s)** awaiting PM review.

You can review, approve, or issue them from the **Requests** tab.`;
  }
  if (technicalScore > 3) {
    return `### \u{1F3D7}\uFE0F CDL Technical Standards

**Concrete Mix Ratios:**
\u2022 Class 15 (1:3:6) \u2014 Blinding, non-structural
\u2022 Class 20 (1:2:4) \u2014 Standard columns, beams, slabs
\u2022 Class 25/30 (1:1.5:3) \u2014 Heavy structural, water-retaining

**Curing:** Minimum 7\u201314 days wet curing (burlap/ponding)
**Slump Test:** 50\u201375mm for pumpable structural concrete`;
  }
  if (greetScore > 2) {
    return `Hi ${userName}! I'm your CDL Site & Inventory Advisor, connected live to all ${ctx.activeSiteCount || 12} project sites.

Currently tracking **${ctx.totalStockItems || 0} stock items** across **${ctx.activeSiteCount || 12} sites** with **${ctx.pendingReqCount || 0} pending requests**.

You can ask me about expiring materials, stock levels, user credentials, site inventories, transfers, costs, or any construction technical question!`;
  }
  if (matchedMaterials.length > 0) {
    const list = matchedMaterials.slice(0, 8).map(
      (m) => `\u2022 **${m.material_name}**: **${m.quantity} ${m.unit || "units"}** @ **${siteName(m.site_id)}** (${m.category || "General"})`
    ).join("\n");
    return `I found **${matchedMaterials.length} matching record(s)** in our live inventory:

${list}${matchedMaterials.length > 8 ? `

*...and ${matchedMaterials.length - 8} more records*` : ""}

Let me know if you need to requisition or transfer any of these!`;
  }
  const isQuestion = q.includes("what") || q.includes("how") || q.includes("who") || q.includes("where") || q.includes("when") || q.includes("which") || q.includes("is there") || q.includes("do we") || q.includes("can i");
  if (isQuestion) {
    return `I'm not sure I caught that exactly \u2014 I'm connected live to all **${ctx.activeSiteCount || 12} CDL sites** and **${ctx.totalStockItems || 0} stock records**.

Try asking me:
\u2022 *"What item is going to expire?"*
\u2022 *"How many users do we have?"*
\u2022 *"What is the stock at Aura Peponi?"*
\u2022 *"Show me low stock items"*
\u2022 *"What are the credentials for [name]?"*
\u2022 *"What is the total inventory value?"*`;
  }
  return `I checked our live system \u2014 we're currently managing **${ctx.activeSiteCount || 12} sites**, **${ctx.activeUserCount || 0} personnel**, and **${ctx.totalStockItems || 0} material records**.

Could you rephrase? I can help with inventory, expiring items, user credentials, transfers, costs, and more.`;
}
exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "authorization, content-type",
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      },
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const authHeader = event.headers["authorization"] || event.headers["Authorization"];
    let user = { role: "admin", name: "User" };
    if (authHeader && authHeader.startsWith("Bearer ")) {
      const jwt = authHeader.slice(7);
      const userRes = await httpsRequest(`${SUPABASE_URL}/auth/v1/user`, {
        method: "GET",
        headers: { apikey: SERVICE_ROLE, Authorization: `Bearer ${jwt}`, "Content-Type": "application/json" }
      });
      if (userRes.status === 200) {
        const authUser = JSON.parse(userRes.body);
        const profileRows = await supabaseQuery(`users?id=eq.${authUser.id}&select=id,role,name,is_active&limit=1`);
        if (profileRows.length) user = profileRows[0];
      }
    }
    const { prompt, systemPrompt, history } = JSON.parse(event.body || "{}");
    if (!prompt || typeof prompt !== "string") {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
        body: JSON.stringify({ error: "Prompt is required" })
      };
    }
    const ctx = await fetchLiveContext(user);
    const reply = generateDeepReasoning(prompt, user, ctx, history);
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({
        reply,
        role: user.role,
        remaining: Infinity,
        liveContextSynced: true
      })
    };
  } catch (err) {
    console.error("[ai-chat] Handler error:", err);
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({
        reply: "I am online and monitoring all 12 CDL construction sites and live stock balances. What would you like to check?",
        role: "user",
        remaining: Infinity
      })
    };
  }
};
